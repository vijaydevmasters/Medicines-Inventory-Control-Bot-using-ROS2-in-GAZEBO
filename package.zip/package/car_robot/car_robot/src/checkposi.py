import rclpy
from sensor_msgs.msg import JointState

def joint_states_callback(msg):
    joint_positions = dict(zip(msg.name, msg.position))
    if 'arm_1_joint' in joint_positions:
        current_position = joint_positions['arm_1_joint']
        print(f"Current position of 'arm_1_joint': {current_position}")

def main(args=None):
    rclpy.init(args=args)
    node = rclpy.create_node('joint_position_listener')
    subscription = node.create_subscription(
        JointState,
        '/joint_states',
        joint_states_callback,
        10  # QoS profile depth
    )

    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.1)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
