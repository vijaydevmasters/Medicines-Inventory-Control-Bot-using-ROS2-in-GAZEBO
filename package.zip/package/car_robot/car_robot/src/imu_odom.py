import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray
from sensor_msgs.msg import JointState
from sensor_msgs.msg import Imu
from math import atan2, sqrt, tan, cos, sin,atan
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
from time import time, sleep
import matplotlib.pyplot as plt



class ProportionalControlNode(Node):

    def __init__(self):
        super().__init__('proportional_control_node')
        qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=10)
        self.joint_position_pub = self.create_publisher(Float64MultiArray, '/position_controller/commands', 10)
        self.wheel_velocities_pub = self.create_publisher(Float64MultiArray, '/velocity_controller/commands', 10)
        self.joint_state_pub = self.create_publisher(JointState, '/joint_states', 10)
        self.imu_msg = self.create_subscription(Imu,'/imu_plugin/out',self.control,qos_profile)
        self.goalx = 10.0 
        self.goaly = 10.0
        self.posx = 0.0
        self.posy = 0.0
        self.error=0.0
        self.error_values=[]
        self.linear_vel_val=[]
    
       
        
    
    
    


    def control(self,imu_msg):
        tstep = .1
        sleep(tstep)
        linear_vel = 0.0
        error_tolerance=0.3
        kp=0.5

        qx = imu_msg.orientation.x
        qy = imu_msg.orientation.y
        qz = imu_msg.orientation.z
        qw = imu_msg.orientation.w 
        steering_center_offset=0.254 #Distance from front steering axle center to centre of the car
        heading_angle = 3.1416 - get_yaw_from_quaternion(qx,qy,qz,qw)
        required_angle = atan((self.goaly-self.posy+steering_center_offset)/(self.goalx-self.posx))
        self.get_logger().info("[ real angle , ideal angle ] : [ %s, %s ]" %(heading_angle,required_angle)) 

        
        error = sqrt((self.goalx-self.posx)**2+(self.goaly-self.posy)**2)



        if( error> error_tolerance):
            linear_vel = -2.0-kp*error
        elif(error< -error_tolerance ):
            linear_vel = 2.0+kp*error
        else:
            linear_vel = 0.0
            self.plot_graphs()
        
        self.posx += cos(heading_angle)*tstep*-linear_vel/10
        self.posy += sin(heading_angle)*tstep*-linear_vel/10
        self.get_logger().info("[ x , y ] : [ %s, %s ]" %(self.posx,self.posy)) 

        self.get_logger().info("[ linear velocity ] : [ %s ]" %-linear_vel)
    
        joint_positions = Float64MultiArray()
        wheel_velocities = Float64MultiArray()
        wheel_velocities.data = [linear_vel, linear_vel, -linear_vel]
        joint_positions.data = [heading_angle-required_angle,heading_angle-required_angle]

        self.joint_position_pub.publish(joint_positions)
        self.wheel_velocities_pub.publish(wheel_velocities)
        self.error_values.append(error)
        self.linear_vel_val.append(linear_vel)

    def plot_graphs(self):
        timestamps = [t * 0.1 for t in range(len(self.error_values))]
        error_graph = [self.error_values[i] for i in range(len(self.error_values))]
        control_graph =[-self.linear_vel_val[j] for j in range(len(self.linear_vel_val))]
        plt.figure()
        plt.plot(timestamps, error_graph, label='error', marker='o', linestyle='-', color='b',linewidth=1)

        # Plot the second dataset on the same graph
        plt.plot(timestamps, control_graph, label='velocity', marker='x', linestyle='-', color='r',linewidth=1)

        # Set labels and title
        plt.title('Error & Velocity vs Time ')
        plt.xlabel('Time')
        plt.ylabel('Error & Velocity')
        plt.legend()
        plt.grid(True)


        plt.show()

def get_yaw_from_quaternion(qx,qy,qz,qw):
        D = sqrt(qx**2+qy**2+qz**2)
        ax = qx/D
        ay = qy/D
        az = qz/D
        Yaw = 2*atan2(D,qw)
        return Yaw

def main(args=None):
    rclpy.init(args=args)
    node = ProportionalControlNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
