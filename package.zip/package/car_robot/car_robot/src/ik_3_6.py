import sympy as sp

# Define symbolic variables for DH parameters
q1, q2, q3, q4, q5, q6 = sp.symbols('q1 q2 q3 q4 q5 q6')

# Define the DH parameters (theta, alpha, a, d)
dh_params = [
    [q1, sp.pi/2, 5, 0],   # Joint 1
    [q2, 0, 0, 0],         # Joint 2
    [q3, 0, 7, 0],         # Joint 3
    [q4, sp.pi/2, 0, 0],   # Joint 4
    [q5, -sp.pi/2, 5, 0],  # Joint 5
    [q6, 0, 0, 0]          # Joint 6
]

# Define the transformation matrices based on DH parameters
def dh_transform(theta, alpha, a, d):
    return sp.Matrix([
        [sp.cos(theta), -sp.sin(theta) * sp.cos(alpha), sp.sin(theta) * sp.sin(alpha), a * sp.cos(theta)],
        [sp.sin(theta), sp.cos(theta) * sp.cos(alpha), -sp.cos(theta) * sp.sin(alpha), a * sp.sin(theta)],
        [0, sp.sin(alpha), sp.cos(alpha), d],
        [0, 0, 0, 1]
    ])

# Compute the overall transformation matrix for the robot arm using DH parameters
def compute_fk(dh_parameters):
    # Initialize identity matrix for the transformation
    T = sp.eye(4)

    # Calculate transformation matrix for each joint and multiply to get the overall transformation
    for i in range(len(dh_parameters)):
        theta, alpha, a, d = dh_parameters[i]
        T_i = dh_transform(theta, alpha, a, d)
        T = T * T_i

    return T

# Define the desired transformation matrix of the end effector (4x4 matrix)
# Replace this matrix with your desired transformation
desired_transformation = sp.Matrix([
    [1, 0, 0, 10],
    [0, 1, 0, 5],
    [0, 0, 1, 5],
    [0, 0, 0, 1]
])

# Compute the symbolic transformation matrix for the robotic arm
robot_transform = compute_fk(dh_params)

# Extract the rotational part (3x3) of the robot's transformation matrix
rotation_matrix = robot_transform[0:3, 0:3]

# Extract the translational part (3x1) of the robot's transformation matrix
translation_matrix = robot_transform[0:3, 3]

# Solve IK for the rotational part (orientation) - (q4, q5, q6)
solutions_orientation = sp.solve(rotation_matrix - desired_transformation[0:3, 0:3], [q4, q5, q6])

# Solve IK for the translational part (position) - (q1, q2, q3)
solutions_position = sp.solve(translation_matrix - desired_transformation[0:3, 3], [q1, q2, q3])

# Print solutions for position and orientation
print("Solutions for position (q1, q2, q3):")
print(solutions_position)
print("\nSolutions for orientation (q4, q5, q6):")
print(solutions_orientation)
