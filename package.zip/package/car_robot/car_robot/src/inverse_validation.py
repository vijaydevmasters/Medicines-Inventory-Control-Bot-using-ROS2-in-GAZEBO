        
from sympy import *
import sympy as sp
import matplotlib.pyplot as plt
import numpy as np

theta = symbols('theta1:7')
alpha = symbols('alpha1:7')
a = symbols('a1:7')
d = symbols('d1:7')
init_printing(use_unicode=True, wrap_line=False)
# Define DH parameter list for transformation matrices
dh_params = [
    (theta[0],           -sp.pi/2,      0,     128),
    (theta[1] - sp.pi/2,  sp.pi ,    612.7,       0),
    (theta[2],             sp.pi,     571.6,      0),
    (theta[3] + sp.pi/2, sp.pi/2,      0,     163.9),
    (theta[4],           -sp.pi/2,     0,     115.7),
    (theta[5],               0,        0,     192.2)
]
def calculate_distance(point1, point2):
    point1 = np.array(point1, dtype=float)
    point2 = np.array(point2, dtype=float)
    # point1 and point2 are tuples or lists representing (x, y, z) coordinates respectively
    x1, y1, z1 = point1
    x2, y2, z2 = point2

    # Calculate Euclidean distance using NumPy
    distance = np.sqrt((x2 - x1)**2 + (y2 - y1)**2 + (z2 - z1)**2)
    return distance

def calculate_velocities(point1, point2, time):
    point1 = np.array(point1, dtype=float)
    point2 = np.array(point2, dtype=float)
    x1, y1, z1 = point1
    x2, y2, z2 = point2

    # Calculate velocities for each axis
    vel_x = (x2 - x1) / time
    vel_y = (y2 - y1) / time
    vel_z = (z2 - z1) / time

    return vel_x, vel_y, vel_z
# Initialize transformation matrix as the identity matrix
T = sp.eye(4)
Z = []
# Calculate transformation matrices and construct the final transformation matrix
for params in dh_params:
    theta_val, alpha_val, a_val, d_val = params
    A = sp.Matrix([
        [sp.cos(theta_val), -sp.sin(theta_val)*sp.cos(alpha_val), sp.sin(theta_val)*sp.sin(alpha_val), a_val*sp.cos(theta_val)],
        [sp.sin(theta_val), sp.cos(theta_val)*sp.cos(alpha_val), -sp.cos(theta_val)*sp.sin(alpha_val), a_val*sp.sin(theta_val)],
        [0, sp.sin(alpha_val), sp.cos(alpha_val), d_val],
        [0, 0, 0, 1]
    ])
    T = T * A
    Z.append([T[0, 2], T[1, 2], T[2, 2]])
#joint_positions = Float64MultiArray()
new_matrix = sp.Matrix(Z)
x_p_matrix = sp.Matrix([[T.col(3)[0]], [T.col(3)[1]], [T.col(3)[2]]])
# Calculate Jacobian matrix components
partial_xp_theta = [sp.diff(x_p_matrix, theta[i]) for i in range(6)]
z_values = [new_matrix.row(i).transpose() for i in range(6)]
J = [sp.Matrix([[partial_xp_theta[i]], [z_values[i]]]) for i in range(6)]
jacobian_matrix = sp.Matrix([J])
theta_vals = [1.53804244, -1.74568355 , 0.86857847 ,-1.30700568 ,-2.42097003 , 1.66764734]
sp.pprint(T.subs(dict(zip(theta, theta_vals))))
T_=T.subs(dict(zip(theta, theta_vals)))
#joint_positions.data = [0.0 , 0.0 , -float(theta_vals[0]), -float(theta_vals[1]) ,  float(theta_vals[2]), 
#float(theta_vals[3]) ,  -float(theta_vals[4]) , float(theta_vals[5])]
print(sp.pi)
#self.joint_position_pub.publish(joint_positions) 
X_plot = []
Y_plot=[]
Z_plot = []
time=[]
p=0
point_a = (T_[3], T_[7], T_[11])
print(point_a)
point_b = (-356.1, 500, 1000)
result_distance = calculate_distance(point_a, point_b)
print(f"Distance: {result_distance}")

#joint_positions = Float64MultiArray()
time_taken=10
velocities = calculate_velocities(point_a, point_b, time_taken)
print(f"velocities: {velocities}")
updated_jacobian_matrix = jacobian_matrix.subs(dict(zip(theta, theta_vals)))
iterations=10
time_corresponding_angle = np.linspace(0,result_distance,iterations)
dt = time_taken/iterations

# print(velocities)
# for t in time_corresponding_angle:
#     print("the angle now iterating is "+str(t))
#     Vx = velocities[0]
#     Vy = velocities[1]
#     Vz = velocities[2]
#     Wx =0
#     Wy = 0
#     Wz = 0
#     print(Vy)
#     X_dot = np.array([[Vx], [Vy], [Vz], [Wx], [Wy], [Wz]])
#     #print(theta_vals)
#     #joint_positions.data = [0.0 , 0.0 , -float(theta_vals[0]), -float(theta_vals[1]) ,  float(theta_vals[2]), 
#     #float(theta_vals[3]) ,  float(theta_vals[4]) , float(theta_vals[5])]
#     #print(sp.pi)
#     #self.joint_position_pub.publish(joint_positions) 
#     # Substitute current joint angles into Jacobian matrix
#     updated_jacobian_matrix = jacobian_matrix.subs(dict(zip(theta, theta_vals)))
#     #updated_jacobian_matrix = jacobian_func(*theta_vals)
#     updated_T_60 = T.subs(dict(zip(theta, theta_vals)))
#     X_plot.append(updated_T_60[3])
#     Y_plot.append(updated_T_60[7])
#     print(updated_T_60[3],end=" ")
#     print(updated_T_60[7],end=" ")
#     print(updated_T_60[11])
#     Z_plot.append(updated_T_60[11])
#     p=p+dt
#     time.append(p)
#     # Calculate joint angle velocities using the pseudo-inverse of Jacobian matrix
#     theta_dot = (updated_jacobian_matrix.pinv() * X_dot).evalf()
#     #theta_dot = np.dot(np.linalg.pinv(updated_jacobian_matrix), X_dot)
#     for i in range(6):
#         theta_vals[i] += theta_dot[i] * dt
#     print(theta_vals)
# # Plotting
# plt.figure()
# plt.plot(Y_plot, Z_plot)
# plt.xlabel('Ypoints')
# plt.ylabel('time')
# plt.title('2D Plot')
# plt.axis('equal')
# plt.show()