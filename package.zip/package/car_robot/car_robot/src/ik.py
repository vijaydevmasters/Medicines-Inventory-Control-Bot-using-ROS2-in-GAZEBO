#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import Float64MultiArray
from sensor_msgs.msg import JointState
import sys
import select
import tty
import time
import termios
from pynput import keyboard
from sympy import *
import sympy as sp
import matplotlib.pyplot as plt
import numpy as np
from sympy.utilities.lambdify import lambdify
from scipy.optimize import minimize
# Define key codes
LIN_VEL_STEP_SIZE = 0.5
ANG_VEL_STEP_SIZE = 0.1

class KeyboardControlNode(Node):

    def __init__(self):
        super().__init__('keyboard_control_node')

        self.joint_position_pub = self.create_publisher(Float64MultiArray, '/position_controller/commands', 10)
        self.wheel_velocities_pub = self.create_publisher(Float64MultiArray, '/velocity_controller/commands', 10)
        self.joint_state_pub = self.create_publisher(JointState, '/joint_states', 10)

        self.settings = termios.tcgetattr(sys.stdin)


    def ikposi(self):

# Define the Denavit-Hartenberg transformation matrix function
        def dh_transform(a, alpha, d, theta):
            return np.array([
                [np.cos(theta), -np.sin(theta) * np.cos(alpha), np.sin(theta) * np.sin(alpha), a * np.cos(theta)],
                [np.sin(theta), np.cos(theta) * np.cos(alpha), -np.cos(theta) * np.sin(alpha), a * np.sin(theta)],
                [0, np.sin(alpha), np.cos(alpha), d],
                [0, 0, 0, 1]
            ])

        # Define the forward kinematics function
        def forward_kinematics(dh_params, joint_angles):
            T = np.identity(4)
            for i in range(6):
                T = np.dot(T, dh_transform(dh_params[i][0], dh_params[i][1], dh_params[i][2], joint_angles[i]))
            return T

        # Define the orientation error calculation
        def orientation_error(desired_orientation, current_orientation):
            R_desired = np.array(desired_orientation)
            R_current = np.array(current_orientation)
            R_error = np.dot(R_desired.T, R_current)
            trace_value = np.trace(R_error)
            trace_value = max(min(trace_value, 3), -1)  # Ensure trace is in the valid range for acos
            angle_error = np.arccos((trace_value - 1) / 2)
            return angle_error

        # Define the objective function for optimization
        def objective_function(joint_angles, desired_pose, dh_params):
            current_pose = forward_kinematics(dh_params, joint_angles)
            position_difference = np.linalg.norm(current_pose[:3, 3] - desired_pose[:3, 3])
            orientation_difference = orientation_error(desired_pose[:3, :3], current_pose[:3, :3])
            total_error = position_difference + orientation_difference
            return total_error

        # Define the inverse kinematics function using numerical optimization
        def inverse_kinematics(dh_params, desired_pose, initial_gues,d_theta):
            # Define bounds for the joint angles
            joint_bounds = [(-np.pi, np.pi)] * 6  # Typical bounds for a robot joint
            result = minimize(objective_function, initial_guess, args=(desired_pose, dh_params),
                            method='SLSQP', bounds=joint_bounds)
            return result.x if False else np.round(d_theta * 0.999, 6)

        # DH parameters for the robot, adjusted for direct use without 'eval'
        dh_params = [
            [0, np.radians(-90), 128, None],  # theta1 will be determined by optimization
            [612.7, np.radians(180), 0, None],  # theta2 will be determined by optimization
            [571.6, np.radians(180), 0, None],  # theta3 will be determined by optimization
            [0, np.radians(90), 163.9, None],  # theta4 will be determined by optimization
            [0, np.radians(-90), 115.7, None],  # theta5 will be determined by optimization
            [0, 0, 92.2 + 100, None]  # theta6 will be determined by optimization, pen length included
        ]

        # Desired end-effector pose (position and orientation)
        desired_position_new = np.array([-187.4, 995.4, 600])
        d_theta=np.array([ 1.6,0.55,-0.95,0.1,-1.6 , 0.0  ])
        # Define the desired orientation for the end-effector to face the ground (downwards)
        desired_orientation_downwards = np.array([
            [1, 0, 0],  # X-axis
            [0, 0, -1], # Y-axis facing downwards
            [0, 1, 0]   # Z-axis
        ])
        desired_pose = np.identity(4)
        desired_pose[:3, 3] = desired_position_new
        desired_pose[:3, :3] = desired_orientation_downwards

        # Initial guess for the joint angles, in radians
        initial_guess = np.array([0, -np.pi/2, 0, np.pi/2, 0, 0])
        home_posi=np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0])

        # Solve the inverse kinematics problem for the new position
        joint_angles_new_position = inverse_kinematics(dh_params, desired_pose, initial_guess,d_theta)


        # Check if a solution was found for the new position with the end-effector facing downwards
        if joint_angles_new_position is not None:
            print("Adjusted joint angles in radians for new position:", joint_angles_new_position)
            
        else:
            print("No solution was found for the new position.")
        

        intermediate_values = np.linspace(home_posi, joint_angles_new_position, 100)
        joint_positions = Float64MultiArray()
        for values in intermediate_values:
                print(intermediate_values)
                joint_positions.data = [-1.0 ,  -1.0  , -values[0] ,   -values[1]  ,values[2]  ,values[3]  ,-values[4],  values[5]]
                self.joint_position_pub.publish(joint_positions)
                time.sleep(0.2)
        
        joint_positions.data = [0.2 ,  0.2  , -joint_angles_new_position[0] ,   -joint_angles_new_position[1]  ,joint_angles_new_position[2]  ,joint_angles_new_position[3]  ,-joint_angles_new_position[4],  joint_angles_new_position[5]]
        self.joint_position_pub.publish(joint_positions)
        time.sleep(0.2)

        intermediate_values = np.linspace( joint_angles_new_position,home_posi, 100)
        joint_positions = Float64MultiArray()
        for values in intermediate_values:
                print(intermediate_values)
                joint_positions.data = [0.2 ,  0.2 , -values[0] ,   -values[1]  ,values[2]  ,values[3]  ,-values[4],  values[5]]
                self.joint_position_pub.publish(joint_positions)
                time.sleep(0.2)
        


        time.sleep(0.2)
        desired_position_new = np.array([129.4, -1004, 495])
        d_theta=np.array([-1.6,0.55,-0.95,0.1,-1.6,0.0 ])
        # Define the desired orientation for the end-effector to face the ground (downwards)
        desired_orientation_downwards = np.array([
            [1, 0, 0],  # X-axis
            [0, 0, -1], # Y-axis facing downwards
            [0, 1, 0]   # Z-axis
        ])
        desired_pose = np.identity(4)
        desired_pose[:3, 3] = desired_position_new
        desired_pose[:3, :3] = desired_orientation_downwards
        joint_angles_new_position = inverse_kinematics(dh_params, desired_pose, initial_guess,d_theta)
        time.sleep(0.2)

        intermediate_values = np.linspace(home_posi, joint_angles_new_position, 100)
        joint_positions = Float64MultiArray()
        for values in intermediate_values:
                print(intermediate_values)
                joint_positions.data = [0.2 ,  0.2  , -values[0] ,   -values[1]  ,values[2]  ,values[3]  ,-values[4],  values[5]]
                self.joint_position_pub.publish(joint_positions)
                time.sleep(0.2)
        joint_positions.data = [-0.5 ,  -0.5  , -joint_angles_new_position[0] ,   -joint_angles_new_position[1]  ,joint_angles_new_position[2]  ,joint_angles_new_position[3]  ,-joint_angles_new_position[4],  joint_angles_new_position[5]]
        self.joint_position_pub.publish(joint_positions)


                
        



            


        










def main(args=None):
    rclpy.init(args=args)
    node = KeyboardControlNode()
    node.ikposi()
    #node.run_keyboard_control()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
