#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import Float64MultiArray
from sensor_msgs.msg import JointState
import sys
import select
import tty
import termios
from pynput import keyboard
from sympy import *
import sympy as sp
import matplotlib.pyplot as plt
import numpy as np
from sympy.utilities.lambdify import lambdify
from scipy.optimize import minimize
# Define key codes
LIN_VEL_STEP_SIZE = 0.5
ANG_VEL_STEP_SIZE = 0.1

class KeyboardControlNode(Node):

    def __init__(self):
        super().__init__('keyboard_control_node')

        self.joint_position_pub = self.create_publisher(Float64MultiArray, '/position_controller/commands', 10)
        self.wheel_velocities_pub = self.create_publisher(Float64MultiArray, '/velocity_controller/commands', 10)
        self.joint_state_pub = self.create_publisher(JointState, '/joint_states', 10)

        self.settings = termios.tcgetattr(sys.stdin)

    def getKey(self):
        tty.setraw(sys.stdin.fileno())
        rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
        if rlist:
            key = sys.stdin.read(1)
        else:
            key = ''

        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)
        return key

    # def ik(self):


    #     theta = symbols('theta1:7')
    #     alpha = symbols('alpha1:7')
    #     a = symbols('a1:7')
    #     d = symbols('d1:7')
    #     init_printing(use_unicode=True, wrap_line=False)
    #     # Define DH parameter list for transformation matrices
        dh_params = [
            (theta[0],           -sp.pi/2,      0,     128),
            (theta[1] - sp.pi/2,  sp.pi ,    612.7,       0),
            (theta[2],             sp.pi,     571.6,      0),
            (theta[3] + sp.pi/2, sp.pi/2,      0,     163.9),
            (theta[4],           -sp.pi/2,     0,     115.7),
            (theta[5],               0,        0,     192.2)
        ]
    #     def calculate_distance(point1, point2):
    #         point1 = np.array(point1, dtype=float)
    #         point2 = np.array(point2, dtype=float)
    #         # point1 and point2 are tuples or lists representing (x, y, z) coordinates respectively
    #         x1, y1, z1 = point1
    #         x2, y2, z2 = point2

    #         # Calculate Euclidean distance using NumPy
    #         distance = np.sqrt((x2 - x1)**2 + (y2 - y1)**2 + (z2 - z1)**2)
    #         return distance

    #     def calculate_velocities(point1, point2, time):
    #         point1 = np.array(point1, dtype=float)
    #         point2 = np.array(point2, dtype=float)
    #         x1, y1, z1 = point1
    #         x2, y2, z2 = point2

    #         # Calculate velocities for each axis
    #         vel_x = (x2 - x1) / time
    #         vel_y = (y2 - y1) / time
    #         vel_z = (z2 - z1) / time

    #         return vel_x, vel_y, vel_z
    #     # Initialize transformation matrix as the identity matrix
    #     T = sp.eye(4)
    #     Z = []
    #     # Calculate transformation matrices and construct the final transformation matrix
    #     for params in dh_params:
    #         theta_val, alpha_val, a_val, d_val = params
    #         A = sp.Matrix([
    #             [sp.cos(theta_val), -sp.sin(theta_val)*sp.cos(alpha_val), sp.sin(theta_val)*sp.sin(alpha_val), a_val*sp.cos(theta_val)],
    #             [sp.sin(theta_val), sp.cos(theta_val)*sp.cos(alpha_val), -sp.cos(theta_val)*sp.sin(alpha_val), a_val*sp.sin(theta_val)],
    #             [0, sp.sin(alpha_val), sp.cos(alpha_val), d_val],
    #             [0, 0, 0, 1]
    #         ])
    #         T = T * A
    #         Z.append([T[0, 2], T[1, 2], T[2, 2]])
    #     joint_positions = Float64MultiArray()
    #     new_matrix = sp.Matrix(Z)
    #     x_p_matrix = sp.Matrix([[T.col(3)[0]], [T.col(3)[1]], [T.col(3)[2]]])
    #     # Calculate Jacobian matrix components
    #     partial_xp_theta = [sp.diff(x_p_matrix, theta[i]) for i in range(6)]
    #     z_values = [new_matrix.row(i).transpose() for i in range(6)]
    #     J = [sp.Matrix([[partial_xp_theta[i]], [z_values[i]]]) for i in range(6)]
    #     jacobian_matrix = sp.Matrix([J])
    #     theta_vals = [sp.pi/2 ,   -sp.pi/6 ,   sp.pi/4+sp.pi/9 ,   -sp.pi/4,   sp.pi/2,     0.0]
    #     sp.pprint(T.subs(dict(zip(theta, theta_vals))))
    #     T_=T.subs(dict(zip(theta, theta_vals)))
    #     joint_positions.data = [0.0 , 0.0 , -float(theta_vals[0]), -float(theta_vals[1]) ,  float(theta_vals[2]), 
    #     float(theta_vals[3]) ,  -float(theta_vals[4]) , float(theta_vals[5])]
    #     print(sp.pi)
    #     self.joint_position_pub.publish(joint_positions) 
    #     X_plot = []
    #     Y_plot=[]
    #     Z_plot = []
    #     time=[]
    #     p=0
    #     point_a = (T_[3], T_[7], T_[11])
    #     print(point_a)
    #     point_b = (-356.1, 800, 800)
    #     result_distance = calculate_distance(point_a, point_b)
    #     print(f"Distance: {result_distance}")

    #     #joint_positions = Float64MultiArray()
    #     time_taken=10
    #     velocities = calculate_velocities(point_a, point_b, time_taken)
    #     updated_jacobian_matrix = jacobian_matrix.subs(dict(zip(theta, theta_vals)))
    #     iterations=500
    #     time_corresponding_angle = np.linspace(0,result_distance,iterations)
    #     dt = time_taken/iterations
    #     #jacobian_func = lambdify(theta, jacobian_matrix)
    #     print(velocities)
    #     for t in time_corresponding_angle:
    #         print("the angle now iterating is "+str(t))
    #         Vx = velocities[0]/iterations
    #         Vy = velocities[1]/iterations
    #         Vz = velocities[2]/iterations
    #         Wx =0
    #         Wy = 0
    #         Wz = 0
    #         print(Vy)
    #         X_dot = np.array([[Vx], [Vy], [Vz], [Wx], [Wy], [Wz]])
    #         #print(theta_vals)
    #         joint_positions.data = [0.0 , 0.0 , -float(theta_vals[0]), -float(theta_vals[1]) ,  float(theta_vals[2]), 
    #         float(theta_vals[3]) ,  float(theta_vals[4]) , float(theta_vals[5])]
    #         #print(sp.pi)
    #         self.joint_position_pub.publish(joint_positions) 
    #         # Substitute current joint angles into Jacobian matrix
    #         updated_jacobian_matrix = jacobian_matrix.subs(dict(zip(theta, theta_vals)))
    #         #updated_jacobian_matrix = jacobian_func(*theta_vals)
    #         updated_T_60 = T.subs(dict(zip(theta, theta_vals)))
    #         X_plot.append(updated_T_60[3])
    #         Y_plot.append(updated_T_60[7])
    #         print(updated_T_60[3],end=" ")
    #         print(updated_T_60[7],end=" ")
    #         print(updated_T_60[11])
    #         Z_plot.append(updated_T_60[11])
    #         p=p+dt
    #         time.append(p)
    #         # Calculate joint angle velocities using the pseudo-inverse of Jacobian matrix
    #         theta_dot = (updated_jacobian_matrix.pinv() * X_dot).evalf()
    #         #theta_dot = np.dot(np.linalg.pinv(updated_jacobian_matrix), X_dot)
    #         for i in range(6):
    #             theta_vals[i] += theta_dot[i] * dt
    #     # Plotting
    #     plt.figure()
    #     plt.plot(Y_plot, Z_plot)
    #     plt.xlabel('Ypoints')
    #     plt.ylabel('time')
    #     plt.title('2D Plot')
    #     plt.axis('equal')
    #     plt.show()
    def ikposi(self):



        # Define symbols for joint angles
        theta = symbols('theta1:7')

        # Define DH parameter list for transformation matrices
        dh_params = [
            (theta[0],           -sp.pi/2,      0,     128),
            (theta[1] - sp.pi/2,  sp.pi ,    612.7,       0),
            (theta[2],             sp.pi,     571.6,      0),
            (theta[3] + sp.pi/2, sp.pi/2,      0,     163.9),
            (theta[4],           -sp.pi/2,     0,     115.7),
            (theta[5],               0,        0,     192.2)
        ]

        # Initialize transformation matrix as the identity matrix
        T = sp.eye(4)
        Z = []

        # Calculate transformation matrices and construct the final transformation matrix
        for params in dh_params:
            theta_val, alpha_val, a_val, d_val = params
            A = sp.Matrix([
                [sp.cos(theta_val), -sp.sin(theta_val)*sp.cos(alpha_val), sp.sin(theta_val)*sp.sin(alpha_val), a_val*sp.cos(theta_val)],
                [sp.sin(theta_val), sp.cos(theta_val)*sp.cos(alpha_val), -sp.cos(theta_val)*sp.sin(alpha_val), a_val*sp.sin(theta_val)],
                [0, sp.sin(alpha_val), sp.cos(alpha_val), d_val],
                [0, 0, 0, 1]
            ])
            T = T * A
            Z.append([T[0, 2], T[1, 2], T[2, 2]])

        new_matrix = sp.Matrix(Z)
        x_p_matrix = sp.Matrix([[T.col(3)[0]], [T.col(3)[1]], [T.col(3)[2]]])

        # Calculate Jacobian matrix components
        partial_xp_theta = [sp.diff(x_p_matrix, theta[i]) for i in range(6)]
        z_values = [new_matrix.row(i).transpose() for i in range(6)]
        J = [sp.Matrix([[partial_xp_theta[i]], [z_values[i]]]) for i in range(6)]
        jacobian_matrix = sp.Matrix([J])

        # Lambdify Jacobian for numerical evaluation
        jacobian_func = lambdify(theta, jacobian_matrix, modules='numpy')

        # Initialize joint angles (all zero, assuming home position)
        theta_vals = np.array([0.0,0.0,0.0,0.0,0.0,0.0])

        # Time parameters
        total_time = 1  # Total time to reach the target
        dt = 0.001  # Time step for simulation
        num_steps = int(total_time / dt)

        # # Target end-effector position
        # target_position = Matrix([500, 0, 500])
        time_corresponding_angle = np.linspace(0, np.pi*2, num_steps)
        # Initialize arrays for plotting
        X_plot = []
        Y_plot = []
        Z_plot = []
        time = []
        p = 0
        # joint_positions = Float64MultiArray()
        # Simulation loop to calculate trajectory in Y-Z plane
        joint_positions = Float64MultiArray()
        for step in time_corresponding_angle:
            print(f"Iterating angle: {step}")
            if (step > np.pi):
                break
            p += step
            time.append(p)
            
            # Calculate required end-effector velocity to move in a straight line to the target
            #remaining_time = total_time - t
            current_position = lambdify(theta, T)(*theta_vals)
            #sp.pprint(current_position)
            Vx = (-250) * 2* (np.pi / total_time) * sp.sin((step + np.pi/2) )
            Vy = 0
            Vz = (250) * 2*  (np.pi / total_time) * sp.cos((step + np.pi/2)  )
            Wx = 0
            Wy = 0
            Wz = 0
            velocity = np.array([[Vx], [Vy], [Vz], [Wx], [Wy], [Wz]], dtype='float')
            
            #velocity = np.array((target_position - current_position) / remaining_time, dtype='float')
            
            # Evaluate the Jacobian matrix at the current joint angles
            J_num = jacobian_func(*theta_vals)
            
            # Calculate joint velocities (including angular velocities)
            joint_velocities = np.linalg.pinv(J_num) @ velocity
            
            # Integrate joint velocities to update joint angles
            theta_vals += joint_velocities.flatten() * dt


            joint_positions.data = [0.0 , 0.0 , -float(theta_vals[0]), -float(theta_vals[1]) ,  float(theta_vals[2]), 
                float(theta_vals[3]) ,  -float(theta_vals[4]) , float(theta_vals[5])]
            self.joint_position_pub.publish(joint_positions)
            
            # Record the current end-effector Y and Z for plotting
            X_plot.append(current_position[0][3])
            Y_plot.append(current_position[1][3])
            Z_plot.append(current_position[2][3])
        sp.pprint(current_position)
        # Plot the trajectory in the Y-Z plane
        plt.figure()
        plt.plot(X_plot, Z_plot)
        plt.xlabel('X position (mm)')
        plt.ylabel('Z position (mm))')
        plt.title('X vs Z')
        plt.axis('equal')
        plt.show()




    def run_keyboard_control(self):
        self.msg = """
        Control Your Car!
        ---------------------------
        Moving around:
            w
        a    s    d

        q : force stop

        Esc to quit
        """

        self.get_logger().info(self.msg)
        joint_positions = Float64MultiArray()
        LIN_VEL_STEP_SIZE=0.05
        joint1 = 0.0
        joint2 = 0.0
        joint3 = 0.0
        joint4 = 0.0
        joint5 = 0.0
        joint6 = 0.0


        while True:
            key = self.getKey()
            if key is not None:
                if key == '\x1b':  # Escape key
                    break
                elif key == 'q':  # Quit
                    joint1 = 0.0
                    joint2 = 0.0
                    joint3 = 0.0
                    joint4 = 0.0
                    joint5 = 0.0
                    joint6 = 0.0
                elif key == 'w':  # Forward
                    joint1 +=LIN_VEL_STEP_SIZE
                    print(joint1)
                elif key == 's':  # Reverse
                    joint1 -= LIN_VEL_STEP_SIZE
                    print(joint1)
                elif key == 'e':  # Forward
                    joint2 +=LIN_VEL_STEP_SIZE
                    print(joint2)
                elif key == 'd':  # Reverse
                    joint2 -= LIN_VEL_STEP_SIZE
                    print(joint2)
                elif key == 'r':  # Forward
                    joint3 +=LIN_VEL_STEP_SIZE
                    print(joint3)
                elif key == 'f':  # Reverse
                    joint3 -= LIN_VEL_STEP_SIZE
                    print(joint3)
                elif key == 't':  # Forward
                    joint4 +=LIN_VEL_STEP_SIZE
                    print(joint4)
                elif key == 'g':  # Reverse
                    joint4 -= LIN_VEL_STEP_SIZE
                    print(joint4)
                elif key == 'y':  # Forward
                    joint5 +=LIN_VEL_STEP_SIZE
                    print(joint5)
                elif key == 'h':  # Reverse
                    joint5 -= LIN_VEL_STEP_SIZE
                    print(joint5)
                elif key == 'u':  # Forward
                    joint6 +=LIN_VEL_STEP_SIZE
                    print(joint6)
                elif key == 'j':  # Reverse
                    joint6 -= LIN_VEL_STEP_SIZE
                    print(joint6)
                elif key == 'z':  # Reverse

                    theta = symbols('theta1:7')

                    # Define DH parameter list for transformation matrices
                    dh_params = [
                        (theta[0],           -sp.pi/2,      0,     128),
                        (theta[1] - sp.pi/2,  sp.pi ,    612.7,       0),
                        (theta[2],             sp.pi,     571.6,      0),
                        (theta[3] + sp.pi/2, sp.pi/2,      0,     163.9),
                        (theta[4],           -sp.pi/2,     0,     115.7),
                        (theta[5],               0,        0,     192.2)
                    ]

                    # Initialize transformation matrix as the identity matrix
                    T = sp.eye(4)
                    Z = []

                    # Calculate transformation matrices and construct the final transformation matrix
                    for params in dh_params:
                        theta_val, alpha_val, a_val, d_val = params
                        A = sp.Matrix([
                            [sp.cos(theta_val), -sp.sin(theta_val)*sp.cos(alpha_val), sp.sin(theta_val)*sp.sin(alpha_val), a_val*sp.cos(theta_val)],
                            [sp.sin(theta_val), sp.cos(theta_val)*sp.cos(alpha_val), -sp.cos(theta_val)*sp.sin(alpha_val), a_val*sp.sin(theta_val)],
                            [0, sp.sin(alpha_val), sp.cos(alpha_val), d_val],
                            [0, 0, 0, 1]
                        ])
                        T = T * A
                    theta_vals = np.array([joint1,joint2,joint3,joint4,joint5,joint6])
                    current_position = lambdify(theta, T)(*theta_vals)
                    sp.pprint(current_position)
                    print(theta_vals)
                    
                    

                


                


                
                joint_positions.data = [-1.0 ,  -1.0  , -joint1 ,   -joint2  ,joint3  ,  joint4  ,-joint5,  joint6]

                self.joint_position_pub.publish(joint_positions)



def main(args=None):
    rclpy.init(args=args)
    node = KeyboardControlNode()
    node.ikposi()
    #node.run_keyboard_control()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
