import numpy as np
from scipy.optimize import minimize

# Define the Denavit-Hartenberg transformation matrix function
def dh_transform(a, alpha, d, theta):
    return np.array([
        [np.cos(theta), -np.sin(theta) * np.cos(alpha), np.sin(theta) * np.sin(alpha), a * np.cos(theta)],
        [np.sin(theta), np.cos(theta) * np.cos(alpha), -np.cos(theta) * np.sin(alpha), a * np.sin(theta)],
        [0, np.sin(alpha), np.cos(alpha), d],
        [0, 0, 0, 1]
    ])

# Define the forward kinematics function
def forward_kinematics(dh_params, joint_angles):
    T = np.identity(4)
    for i in range(6):
        T = np.dot(T, dh_transform(dh_params[i][0], dh_params[i][1], dh_params[i][2], joint_angles[i]))
    return T

# Define the orientation error calculation
def orientation_error(desired_orientation, current_orientation):
    R_desired = np.array(desired_orientation)
    R_current = np.array(current_orientation)
    R_error = np.dot(R_desired.T, R_current)
    trace_value = np.trace(R_error)
    trace_value = max(min(trace_value, 3), -1)  # Ensure trace is in the valid range for acos
    angle_error = np.arccos((trace_value - 1) / 2)
    return angle_error

# Define the objective function for optimization
def objective_function(joint_angles, desired_pose, dh_params):
    current_pose = forward_kinematics(dh_params, joint_angles)
    position_difference = np.linalg.norm(current_pose[:3, 3] - desired_pose[:3, 3])
    orientation_difference = orientation_error(desired_pose[:3, :3], current_pose[:3, :3])
    total_error = position_difference + orientation_difference
    return total_error

# Define the inverse kinematics function using numerical optimization
def inverse_kinematics(dh_params, desired_pose, initial_guess):
    # Define bounds for the joint angles
    joint_bounds = [(-np.pi, np.pi)] * 6  # Typical bounds for a robot joint
    result = minimize(objective_function, initial_guess, args=(desired_pose, dh_params),
                      method='SLSQP', bounds=joint_bounds)
    return result.x if result.success else None

# DH parameters for the robot, adjusted for direct use without 'eval'
dh_params = [
    [0, np.radians(-90), 128, None],  # theta1 will be determined by optimization
    [612.7, np.radians(180), 0, None],  # theta2 will be determined by optimization
    [571.6, np.radians(180), 0, None],  # theta3 will be determined by optimization
    [0, np.radians(90), 163.9, None],  # theta4 will be determined by optimization
    [0, np.radians(-90), 115.7, None],  # theta5 will be determined by optimization
    [0, 0, 92.2 + 100, None]  # theta6 will be determined by optimization, pen length included
]

# Desired end-effector pose (position and orientation)
desired_position_new = np.array([-187.4, 995.4, 600])
# Define the desired orientation for the end-effector to face the ground (downwards)
desired_orientation_downwards = np.array([
    [1, 0, 0],  # X-axis
    [0, 0, -1], # Y-axis facing downwards
    [0, 1, 0]   # Z-axis
])
desired_pose = np.identity(4)
desired_pose[:3, 3] = desired_position_new
desired_pose[:3, :3] = desired_orientation_downwards

# Initial guess for the joint angles, in radians
initial_guess = np.array([0, -np.pi/2, 0, np.pi/2, 0, 0])

# Solve the inverse kinematics problem for the new position
joint_angles_new_position = inverse_kinematics(dh_params, desired_pose, initial_guess)

# Check if a solution was found for the new position with the end-effector facing downwards
if joint_angles_new_position is not None:
    # Adjust the joint angles according to the provided DH parameters
    joint_angles_new_position[1] -= np.pi/2  # theta2 offset
    joint_angles_new_position[3] -= np.pi/2  # theta4 offset
    # joint_positions = Float64MultiArray()
    # joint_positions.data = [0.0 , 0.0 , -float(joint_angles[0]), -float(joint_angles[1]) ,  float(joint_angles[2]), 
    # float(joint_angles[3]) ,  float(joint_angles[4]) , float(joint_angles[5])]
    # self.joint_position_pub.publish(joint_positions)
    
    # The joint angles should be now in the correct range and configuration
    print("Adjusted joint angles in radians for new position:", joint_angles_new_position)
    print("Adjusted joint angles in degrees for new position:", np.degrees(joint_angles_new_position))
else:
    print("No solution was found for the new position.")