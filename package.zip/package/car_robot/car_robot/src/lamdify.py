import numpy as np
import matplotlib.pyplot as plt
from sympy import symbols, Matrix, cos, sin, lambdify, pi,diff
import sympy as sp
# Define symbols for joint angles
theta = symbols('theta1:7')
sp.init_printing(use_unicode=True, wrap_line=False)

# Define DH parameter list for transformation matrices
dh_params = [
    (theta[0],           -sp.pi/2,      0,     128),
    (theta[1] - sp.pi/2,  sp.pi ,    612.7,       0),
    (theta[2],             sp.pi,     571.6,      0),
    (theta[3] + sp.pi/2, sp.pi/2,      0,     163.9),
    (theta[4],           -sp.pi/2,     0,     115.7),
    (theta[5],               0,        0,     192.2)
]

# Initialize transformation matrix as the identity matrix
T = sp.eye(4)
Z = []

# Calculate transformation matrices and construct the final transformation matrix
for params in dh_params:
    theta_val, alpha_val, a_val, d_val = params
    A = sp.Matrix([
        [sp.cos(theta_val), -sp.sin(theta_val)*sp.cos(alpha_val), sp.sin(theta_val)*sp.sin(alpha_val), a_val*sp.cos(theta_val)],
        [sp.sin(theta_val), sp.cos(theta_val)*sp.cos(alpha_val), -sp.cos(theta_val)*sp.sin(alpha_val), a_val*sp.sin(theta_val)],
        [0, sp.sin(alpha_val), sp.cos(alpha_val), d_val],
        [0, 0, 0, 1]
    ])
    T = T * A
    Z.append([T[0, 2], T[1, 2], T[2, 2]])

new_matrix = sp.Matrix(Z)
x_p_matrix = sp.Matrix([[T.col(3)[0]], [T.col(3)[1]], [T.col(3)[2]]])

# Calculate Jacobian matrix components
partial_xp_theta = [sp.diff(x_p_matrix, theta[i]) for i in range(6)]
z_values = [new_matrix.row(i).transpose() for i in range(6)]
J = [sp.Matrix([[partial_xp_theta[i]], [z_values[i]]]) for i in range(6)]
jacobian_matrix = sp.Matrix([J])
sp.pprint(T)
print("----------------------------------------------------")
sp.pprint(jacobian_matrix)

# Lambdify Jacobian for numerical evaluation
jacobian_func = lambdify(theta, jacobian_matrix, modules='numpy')

# Initialize joint angles (all zero, assuming home position)
theta_vals = np.zeros(6)

# Time parameters
total_time = 1  # Total time to reach the target
dt = 0.001  # Time step for simulation
num_steps = int(total_time / dt)

# # Target end-effector position
# target_position = Matrix([500, 0, 500])
time_corresponding_angle = np.linspace(0, np.pi*2, num_steps)
# Initialize arrays for plotting
X_plot = []
Y_plot = []
Z_plot = []
time = []
p = 0
# joint_positions = Float64MultiArray()
# Simulation loop to calculate trajectory in Y-Z plane
for step in time_corresponding_angle:
    print(f"Iterating angle: {step}")
    if (step > np.pi/2):
        break
    p += step
    time.append(p)
    
    # Calculate required end-effector velocity to move in a straight line to the target
    #remaining_time = total_time - t
    current_position = lambdify(theta, T)(*theta_vals)
    #sp.pprint(current_position)
    Vx = (-250) * 2* (np.pi / total_time) * sp.sin((step + np.pi/2) )
    Vy = 0
    Vz = (250) * 2*  (np.pi / total_time) * sp.cos((step + np.pi/2)  )
    Wx = 0
    Wy = 0
    Wz = 0
    velocity = np.array([[Vx], [Vy], [Vz], [Wx], [Wy], [Wz]], dtype='float')
    
    #velocity = np.array((target_position - current_position) / remaining_time, dtype='float')
    
    # Evaluate the Jacobian matrix at the current joint angles
    J_num = jacobian_func(*theta_vals)
    
    # Calculate joint velocities (including angular velocities)
    joint_velocities = np.linalg.pinv(J_num) @ velocity
    
    # Integrate joint velocities to update joint angles
    theta_vals += joint_velocities.flatten() * dt


    # joint_positions.data = [0.0 , 0.0 , -float(theta_vals[0]), -float(theta_vals[1]) ,  float(theta_vals[2]), 
    #        float(theta_vals[3]) ,  float(theta_vals[4]) , float(theta_vals[5])]
    # self.joint_position_pub.publish(joint_positions)
    
    # Record the current end-effector Y and Z for plotting
    X_plot.append(current_position[0][3])
    Y_plot.append(current_position[1][3])
    Z_plot.append(current_position[2][3])

# Plot the trajectory in the Y-Z plane


plt.figure()
plt.plot(X_plot, Z_plot)
plt.xlabel('X position (mm)')
plt.ylabel('Z position (mm))')
plt.title('X vs Z')
plt.axis('equal')
plt.show()
